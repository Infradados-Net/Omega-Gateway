@echo off
echo OMEGA Engine - Instalador Windows x64
echo ======================================
copy omega_core.exe "%USERPROFILE%\omega_core.exe"
echo Binario instalado em %USERPROFILE%\omega_core.exe
echo Execute: omega_core.exe
pause
