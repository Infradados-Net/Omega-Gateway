OMEGA Engine v6.1 — Windows x64
================================
1. Execute INSTALAR.bat como Administrador
2. Ou copie omega_core.exe para qualquer pasta
3. Execute: omega_core.exe

Site: https://www.omegast.pro
Suporte: luciano@omegast.pro
